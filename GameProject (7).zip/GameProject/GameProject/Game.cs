﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameProject
{
   public class Game
    {
        // method to get points
        public int GetPoint(string point)
        {
            {
                int points = int.Parse(point);

                return points;
            }

        }
    }
}

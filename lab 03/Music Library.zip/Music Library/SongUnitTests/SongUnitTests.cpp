#include "pch.h"
#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace SongUnitTests
{
	TEST_CLASS(SongUnitTests)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
		}
	};
}

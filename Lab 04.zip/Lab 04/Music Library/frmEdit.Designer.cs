﻿
namespace Music_Library
{
    partial class frmEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSongName = new System.Windows.Forms.Label();
            this.lblArtist = new System.Windows.Forms.Label();
            this.lblAlbum = new System.Windows.Forms.Label();
            this.lblGenre = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblSongDuration = new System.Windows.Forms.Label();
            this.txtSongName = new System.Windows.Forms.TextBox();
            this.txtArtist = new System.Windows.Forms.TextBox();
            this.txtAlbum = new System.Windows.Forms.TextBox();
            this.txtGenre = new System.Windows.Forms.TextBox();
            this.txtSongYear = new System.Windows.Forms.TextBox();
            this.txtSongDuration = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtId = new System.Windows.Forms.TextBox();
            this.lblID = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblSongName
            // 
            this.lblSongName.AutoSize = true;
            this.lblSongName.Location = new System.Drawing.Point(39, 67);
            this.lblSongName.Name = "lblSongName";
            this.lblSongName.Size = new System.Drawing.Size(86, 17);
            this.lblSongName.TabIndex = 0;
            this.lblSongName.Text = "Song Name:";
            // 
            // lblArtist
            // 
            this.lblArtist.AutoSize = true;
            this.lblArtist.Location = new System.Drawing.Point(39, 106);
            this.lblArtist.Name = "lblArtist";
            this.lblArtist.Size = new System.Drawing.Size(44, 17);
            this.lblArtist.TabIndex = 1;
            this.lblArtist.Text = "Artist:";
            // 
            // lblAlbum
            // 
            this.lblAlbum.AutoSize = true;
            this.lblAlbum.Location = new System.Drawing.Point(39, 145);
            this.lblAlbum.Name = "lblAlbum";
            this.lblAlbum.Size = new System.Drawing.Size(51, 17);
            this.lblAlbum.TabIndex = 2;
            this.lblAlbum.Text = "Album:";
            // 
            // lblGenre
            // 
            this.lblGenre.AutoSize = true;
            this.lblGenre.Location = new System.Drawing.Point(39, 182);
            this.lblGenre.Name = "lblGenre";
            this.lblGenre.Size = new System.Drawing.Size(52, 17);
            this.lblGenre.TabIndex = 3;
            this.lblGenre.Text = "Genre:";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(39, 260);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(79, 17);
            this.lblYear.TabIndex = 4;
            this.lblYear.Text = "Song Year:";
            // 
            // lblSongDuration
            // 
            this.lblSongDuration.AutoSize = true;
            this.lblSongDuration.Location = new System.Drawing.Point(39, 220);
            this.lblSongDuration.Name = "lblSongDuration";
            this.lblSongDuration.Size = new System.Drawing.Size(103, 17);
            this.lblSongDuration.TabIndex = 5;
            this.lblSongDuration.Text = "Song Duration:";
            // 
            // txtSongName
            // 
            this.txtSongName.Location = new System.Drawing.Point(160, 67);
            this.txtSongName.Name = "txtSongName";
            this.txtSongName.Size = new System.Drawing.Size(185, 22);
            this.txtSongName.TabIndex = 6;
            // 
            // txtArtist
            // 
            this.txtArtist.Location = new System.Drawing.Point(160, 103);
            this.txtArtist.Name = "txtArtist";
            this.txtArtist.Size = new System.Drawing.Size(185, 22);
            this.txtArtist.TabIndex = 7;
            // 
            // txtAlbum
            // 
            this.txtAlbum.Location = new System.Drawing.Point(160, 142);
            this.txtAlbum.Name = "txtAlbum";
            this.txtAlbum.Size = new System.Drawing.Size(185, 22);
            this.txtAlbum.TabIndex = 8;
            // 
            // txtGenre
            // 
            this.txtGenre.Location = new System.Drawing.Point(160, 177);
            this.txtGenre.Name = "txtGenre";
            this.txtGenre.Size = new System.Drawing.Size(185, 22);
            this.txtGenre.TabIndex = 9;
            // 
            // txtSongYear
            // 
            this.txtSongYear.Location = new System.Drawing.Point(160, 260);
            this.txtSongYear.Name = "txtSongYear";
            this.txtSongYear.Size = new System.Drawing.Size(185, 22);
            this.txtSongYear.TabIndex = 10;
            // 
            // txtSongDuration
            // 
            this.txtSongDuration.Location = new System.Drawing.Point(160, 220);
            this.txtSongDuration.Name = "txtSongDuration";
            this.txtSongDuration.Size = new System.Drawing.Size(185, 22);
            this.txtSongDuration.TabIndex = 11;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(160, 307);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(151, 33);
            this.btnUpdate.TabIndex = 12;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(160, 29);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(185, 22);
            this.txtId.TabIndex = 23;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(39, 34);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(25, 17);
            this.lblID.TabIndex = 22;
            this.lblID.Text = "ID:";
            // 
            // frmEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(428, 358);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtSongDuration);
            this.Controls.Add(this.txtSongYear);
            this.Controls.Add(this.txtGenre);
            this.Controls.Add(this.txtAlbum);
            this.Controls.Add(this.txtArtist);
            this.Controls.Add(this.txtSongName);
            this.Controls.Add(this.lblSongDuration);
            this.Controls.Add(this.lblYear);
            this.Controls.Add(this.lblGenre);
            this.Controls.Add(this.lblAlbum);
            this.Controls.Add(this.lblArtist);
            this.Controls.Add(this.lblSongName);
            this.Name = "frmEdit";
            this.Text = "frmEdit";
            this.Load += new System.EventHandler(this.frmEdit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSongName;
        private System.Windows.Forms.Label lblArtist;
        private System.Windows.Forms.Label lblAlbum;
        private System.Windows.Forms.Label lblGenre;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblSongDuration;
        private System.Windows.Forms.Button btnUpdate;
        public System.Windows.Forms.TextBox txtSongName;
        public System.Windows.Forms.TextBox txtArtist;
        public System.Windows.Forms.TextBox txtAlbum;
        public System.Windows.Forms.TextBox txtGenre;
        public System.Windows.Forms.TextBox txtSongYear;
        public System.Windows.Forms.TextBox txtSongDuration;
        private System.Windows.Forms.Label lblID;
        public System.Windows.Forms.TextBox txtId;
    }
}
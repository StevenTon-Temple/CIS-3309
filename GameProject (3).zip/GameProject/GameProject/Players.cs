﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameProject
{
    class Players
    {
        private int player_id;
        private string name;
        private int player_score;

        public int Player_Id
        {
            get { return player_id; }
            set { player_id = value; }
        }
        public int Player_score
        {
            get { return player_score; }
            set { player_score = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private void getPlayer()
        {

        }

        private void getPlayerScores()
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameProject
{
    public partial class frmQuestion : Form
    {
        OleDbConnection myConnection;
        OleDbDataAdapter myDataAdapter;
        DataSet songDataSet;
        DataTable songTable;
        BindingSource myBindingSource;
        string strSQL;
        string topic = "";
        string answersfor = "AnswersFor";
        string point;
        public int CorNC;
        public frmQuestion(string topics, string points) {

            InitializeComponent();
            point = points;
            topic = topics;
            answersfor += topic;

        }

       
        private void frmQuestion_Load(object sender, EventArgs e)
        {
            Console.Out.WriteLine(topic);
            Console.Out.WriteLine(answersfor);

            // Connect to the database, retrieve a result set of records, and store them in a DataSet
            myConnection = new OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0;Data Source=JepordyTable.accdb;");
            strSQL = "SELECT * FROM Jepordy";
            myDataAdapter = new OleDbDataAdapter(strSQL, myConnection);
            songDataSet = new DataSet("JepordyTable");
            myDataAdapter.Fill(songDataSet, "JepordyTable");

            strSQL = "SELECT TOP 1 " + topic + ", "+ answersfor + " FROM Jepordy ORDER BY Rnd(-(1000*ID)*Time())";

            // Set the data source for the DataGridView to display the records and their information.
            songTable = songDataSet.Tables["JepordyTable"];
            dgvJeopardy.DataSource = songTable;
            //strSQL = "SELECT TOP 1" + topic +", "+ answersfor + "FROM Jepordy ORDER BY Rnd(-(1000*ID)*Time())";
            ///strSQL = "SELECT TOP 1 Sport, AnswerForSport FROM Jepordy ORDER BY Rnd(-(1000*ID)*Time())";

            //strSQL = "SELECT Sport FROM Jepordy WHERE AnswersForSport = 'Baseball';";
            myDataAdapter = new OleDbDataAdapter(strSQL, myConnection);
            songDataSet = new DataSet("JepordyTable");
            myDataAdapter.Fill(songDataSet, "JepordyTable");
            songTable = songDataSet.Tables["JepordyTable"];
            dgvJeopardy.DataSource = songTable;
            int rowindex = dgvJeopardy.CurrentCell.RowIndex;
            int columnindex = dgvJeopardy.CurrentCell.ColumnIndex;
            lblQuestions.Text = dgvJeopardy.Rows[rowindex].Cells[columnindex].Value.ToString();


        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtanswerfor.Text.Equals(dgvJeopardy.Rows[0].Cells[1].Value.ToString()))
            {
                MessageBox.Show("Answer is correct!");
                CorNC = 1;
                this.Close();
            }
            else
            {
                MessageBox.Show("Answer is incorrect!");
                CorNC = 0;
                this.Close();
                
            }
        }

        private void dgvJeopardy_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
    }


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameProject
{
   public class Game
    {

        public int GetPoint(string point)
        {
            {
                int points = int.Parse(point);

                return points;
            }

        }
    }
}
